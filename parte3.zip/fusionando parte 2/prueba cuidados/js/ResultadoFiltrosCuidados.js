/**
 * Clase 'ResultadoFiltros' que guardará los datos del Json
 */

class ResultadoFiltrosCuidados {
    /**
         * Constructor de clases de la clase ResultadoFiltros
        * @param {any} resultadoCuidados Resultado del filtro 'Cuidados' a guardar
        * */
    constructor(resultadoCuidados) {
        this.resultadoCuidados = resultadoCuidados;
    }
}