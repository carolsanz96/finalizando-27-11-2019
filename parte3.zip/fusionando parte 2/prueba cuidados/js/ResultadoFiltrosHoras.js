/**
 * Clase 'ResultadoFiltros' que guardará los datos del Json
 */

class ResultadoFiltrosHoras {
/**
     * Constructor de clases de la clase ResultadoFiltros
     * @param {any} resultadoFlor Resultado del filtro 'Flor' a guardar
     * @param {any} resultadoCuidados Resultado del filtro 'Cuidados' a guardar
     * @param {any} resultadoHoras Resultado del filtro 'Horas' a guardar
     * */
    constructor(resultadoFlor, resultadoCuidados, resultadoHoras) {
        this.resultadoFlor = resultadoFlor;
        this.resultadoCuidados = resultadoCuidados;
        this.resultadoHoras = resultadoHoras;
    }
}