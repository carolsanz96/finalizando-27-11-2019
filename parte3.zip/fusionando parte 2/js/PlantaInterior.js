/**
 * Clase 'PlantaInterior' que guardará los datos del Json
 */

class PlantaInterior {
    /**
     * Constructor de clases de la clase PlantaInterior
     * @param {any} nombre Nombre de la planta a guardar
     * @param {any} codin Codin de la planta a guardar (unico)
     * @param {any} precio Precio de la planta a guardar
     * @param {any} oferta  Si tiene oferta o no
     * @param {any} ubicacion ubicacion donde se puede colocar la planta
     * @param {any} flor Si tiene flor o no tiene
     * @param {any} cuidados Que tipo de cuidados requiere
     * @param {any} luzdir Si la luz que le tiene que dar es directa o no
     * @param {any} luzindir Cuantas horas de luz indirecta le puede dar
     * @param {any} url url de la imagen/foto de cada planta
     * @param {any} enlace enlace al que te redirige al hacer click en el nombre de la planta
     */
    constructor(nombre, codin, precio, oferta, ubicacion, flor, cuidados, luzdir, luzindir, url, enlace) {
        this.nombre = nombre;
        this.codin = codin;
        this.precio = precio;
        this.oferta = oferta;
        this.ubicacion = ubicacion;
        this.flor = flor;
        this.cuidados = cuidados;
        this.luzdir = luzdir;
        this.luzindir = luzindir;
        this.url = url;
        this.enlace = enlace;
    }
}
