/**
 * Clase 'ResultadoFiltros' que guardará los datos del Json
 */

class ResultadoFiltrosCuidados {
/**
     * Constructor de clases de la clase ResultadoFiltrosCuidados
     * @param {any} resultadoCuidados Resultado del filtro 'Cuidados' a guardar

     * */
    constructor(resultadoCuidados) {
        this.resultadoCuidados = resultadoCuidados;
    }
}