var plantas = {
    "plantasInterior": [
        {
            "nombre": "Phalaenopsis 2 tallos",
            "codin": "203845",
            "precio": "9.99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": true,
            "cuidados": "Normal",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/52336-large_default/orquidea-phalaenopsis-rosa-2-tallos-en-maceta-12cm.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=orquidea&submit_search="
        },
        {
            "nombre": "Hortensia de Interior 3 Litros",
            "codin": "213583",
            "precio": "14.99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Suelo" }
            ],
            "flor": true,
            "cuidados": "Normal",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/54191-large_default/hortensia-variedades.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=hortensia&submit_search="
        },
        {
            "nombre": "Crasa",
            "codin": "087418",
            "precio": "0.65",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": true,
            "luzindir": " ",
            "url": "https://verdecora.es/52185-large_default/crasas-surtido-variado.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=crasa&submit_search="
        },
        {
            "nombre": "Areca",
            "codin": "066826",
            "precio": "12.99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/19261-large_default/areca.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=areca&submit_search="
        },
        {
            "nombre": "Kalanchoe",
            "codin": "322589",
            "precio": "1.59",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": true,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/56215-large_default/kalanchoe-planta-de-interior-en-maceta.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=kalanchoe&submit_search="
        },
        {
            "nombre": "Anthurium",
            "codin": "307142",
            "precio": "7.99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": true,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/48040-large_default/anthurium-surtido-colores.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=anthurium&submit_search="
        },
        {
            "nombre": "Sanseiviera",
            "codin": "344190",
            "precio": "2.99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": true,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "menos de 2 horas",
            "url": "https://verdecora.es/45682-large_default/sanseviera-surtido-variado.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=sanseviera&submit_search="
        },
        {
            "nombre": "Spathiphyllum",
            "codin": "322588",
            "precio": "1,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" },
                { "lugar": "Suelo" }
            ],
            "flor": true,
            "cuidados": "Normal",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/48024-large_default/spathiphyllum-planta.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=Spathiphyllum&submit_search="
        },
        {
            "nombre": "Rosal Mini",
            "codin": "072532",
            "precio": "6.99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": true,
            "cuidados": "Normal",
            "luzdir": false,
            "luzindir": "mas de 6 horas",
            "url": "https://verdecora.es/48036-large_default/rosal-mini-maceta-13-cm.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=rosal+mini&submit_search="
        },
        {
            "nombre": "Gerbera",
            "codin": "073931",
            "precio": "2,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": true,
            "cuidados": "Normal",
            "luzdir": false,
            "luzindir": "mas de 6 horas",
            "url": "https://verdecora.es/48021-large_default/gerbera-maceta-12cm.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=gerbera&submit_search="
        },
        {
            "nombre": "Campanula",
            "codin": "242481",
            "precio": "4,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": true,
            "cuidados": "Normal",
            "luzdir": true,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/48015-large_default/campanula-en-maceta.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=Campanula&submit_search="
        },
        {
            "nombre": "Potho",
            "codin": "135219",
            "precio": "2,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" },
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "menos de 2 horas",
            "url": "https://verdecora.es/19249-large_default/potho.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=photo&submit_search="
        },
        {
            "nombre": "Bromelia",
            "codin": "322586",
            "precio": "3,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": true,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "mas de 6 horas",
            "url": "https://verdecora.es/35502-large_default/bromelia.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=bromelia&submit_search="
        },
        {
            "nombre": "Bananera",
            "codin": "353058",
            "precio": "6,99",
            "oferta": true,
            "ubicacion": [
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Normal",
            "luzdir": false,
            "luzindir": "mas de 6 horas",
            "url": "https://verdecora.es/57021-large_default/bananera-maceta-13cm.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=bananera&submit_search="
        },
        {
            "nombre": "Pilea Peperomioides",
            "codin": "342080",
            "precio": "12,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": false,
            "cuidados": "Normal",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/52324-large_default/pilea-peperomioides-maceta-12cm.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=pilea+peperomioides&submit_search="
        },
        {
            "nombre": "Kentia",
            "codin": "070600",
            "precio": "26,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/13444-large_default/kentia-planta-interior.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=kentia&submit_search="
        },
        {
            "nombre": "Dracenas",
            "codin": "101670",
            "precio": "16,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "menos de 2 horas",
            "url": "https://verdecora.es/19278-large_default/dracena-compacta.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=dracena&submit_search="
        },
        {
            "nombre": "Gardenia",
            "codin": "073292",
            "precio": "6,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": true,
            "cuidados": "Normal",
            "luzdir": true,
            "luzindir": " ",
            "url": "https://verdecora.es/48043-large_default/gardenia-maceta-12cm.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=gardenia&submit_search="
        },
        {
            "nombre": "Tronco de Brasil",
            "codin": "255436",
            "precio": "12.99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/37186-large_default/tronco-del-brasil.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=tronco+brasil&submit_search="
        },
        {
            "nombre": "Carnívoras",
            "codin": "058731",
            "precio": "5,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": false,
            "cuidados": "Normal",
            "luzdir": false,
            "luzindir": "mas de 6 horas",
            "url": "https://verdecora.es/49035-large_default/dionaea-muscipula-planta-carnivora.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=carnivora&submit_search="
        },
        {
            "nombre": "Azucena",
            "codin": "258364",
            "precio": "6,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": true,
            "cuidados": "Normal",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/48027-large_default/azucena-.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=azucena&submit_search="
        },
        {
            "nombre": "Helecho",
            "codin": "106331",
            "precio": "4,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": false,
            "cuidados": "Normal",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/13473-large_default/helecho-maceta-planta-verde.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=helecho&submit_search="
        },
        {
            "nombre": "Ficus Robusta",
            "codin": "104450",
            "precio": "34,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/13344-large_default/ficus-robusta.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=ficus+robusta&submit_search="
        },
        {
            "nombre": "Ficus Danielle",
            "codin": "220426",
            "precio": "12,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/56891-large_default/ficus-danielle.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=ficus+danielle&submit_search="
        },
        {
            "nombre": "Cocotera",
            "codin": "350554",
            "precio": "12,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "mas de 6 horas",
            "url": "https://verdecora.es/56890-large_default/palmera-cocotera.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=cocotera&submit_search="
        },
        {
            "nombre": "Calathea Crocata",
            "codin": "064607",
            "precio": "12,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": true,
            "cuidados": "Normal",
            "luzdir": false,
            "luzindir": "de 2 a 6 horass",
            "url": "https://verdecora.es/21119-large_default/calathea-crocata-en-maceta-o13cm.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=Calathea+Crocata&submit_search="
        },
        {
            "nombre": "Calathea",
            "codin": "350554",
            "precio": "12,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": true,
            "luzindir": " ",
            "url": "https://verdecora.es/14273-large_default/calathea-maceta-3-litros.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=Calathea&submit_search="
        },
        {
            "nombre": "Aloe Vera",
            "codin": "072506",
            "precio": "4,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Suelo" },
                { "lugar": "Estanteria" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": true,
            "luzindir": " ",
            "url": "https://verdecora.es/56202-large_default/aloe-vera.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=aloe+vera&submit_search="
        },
        {
            "nombre": "Tillandsia",
            "codin": "352600",
            "precio": "4,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "menos de 2 horas",
            "url": "https://verdecora.es/57025-large_default/tillandsia-roja.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=tillandsia&submit_search="
        },
        {
            "nombre": "Peperomia",
            "codin": "209139",
            "precio": "5,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/10903-large_default/peperomia-maceta-o12cm.jpg"
        },
        {
            "nombre": "Planta del dinero",
            "codin": "120540",
            "precio": "3,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Estanteria" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/10901-large_default/planta-del-dinero-colgante.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=Planta+del+dinero&submit_search="
        },
        {
            "nombre": "Violeta Africana",
            "codin": "136880",
            "precio": "2,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" }
            ],
            "flor": true,
            "cuidados": "Normal",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/48046-large_default/violeta-africana-maceta-12-cm.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=Violeta+Africana&submit_search="
        },
        {
            "nombre": "Fittonia",
            "codin": "251867",
            "precio": "2,49",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" }
            ],
            "flor": false,
            "cuidados": "Normal",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/13466-large_default/fittonia-maceta-9cm.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=Fittonia&submit_search="
        },
        {
            "nombre": "Schefflera",
            "codin": "131747",
            "precio": "29,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Normal",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/13488-large_default/schefflera-gold.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=Schefflera&submit_search="
        },
        {
            "nombre": "Zamioculca",
            "codin": "101460",
            "precio": "5,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "menos de 2 horas",
            "url": "https://verdecora.es/13485-large_default/zamioculca-en-maceta.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=Zamioculca&submit_search="
        },
        {
            "nombre": "Ripsalis de flor",
            "codin": "110831",
            "precio": "2,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Estanteria" }
            ],
            "flor": true,
            "cuidados": "Bajo",
            "luzdir": true,
            "luzindir": " ",
            "url": "https://verdecora.es/17840-large_default/ripsalis-de-flor.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=Ripsalis+de+flor&submit_search="
        },
        {
            "nombre": "Alocasia",
            "codin": "301329",
            "precio": "6,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Normal",
            "luzdir": false,
            "luzindir": "mas de 6 horas",
            "url": "https://verdecora.es/10908-large_default/alocasia-polly-maceta-o13cm.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=Alocasia&submit_search="
        },
        {
            "nombre": "Beaucarnea",
            "codin": "324326",
            "precio": "14,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/24736-large_default/beaucarnea-recta-maceta.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=Beaucarnea&submit_search="
        },
        {
            "nombre": "Pachira",
            "codin": "091399",
            "precio": "9,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "mas de 6 horas",
            "url": "https://verdecora.es/43336-large_default/pachira.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=Beaucarnea&submit_search="
        },
        {
            "nombre": "Yucca",
            "codin": "113347",
            "precio": "6,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/plantas-verdes/113347-yucca-maceta-12cm.html",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=yucca&submit_search="
        },
        {
            "nombre": "Aspidistra",
            "codin": "142048",
            "precio": "24,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Bajo",
            "luzdir": false,
            "luzindir": "menos de 2 horas",
            "url": "https://verdecora.es/39759-large_default/aspidistra-maceta-3-litros.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=Aspidistra&submit_search="
        },
        {
            "nombre": "Diefembaccia",
            "codin": "250009",
            "precio": "9,99",
            "oferta": false,
            "ubicacion": [
                { "lugar": "Mesa" },
                { "lugar": "Suelo" }
            ],
            "flor": false,
            "cuidados": "Normal",
            "luzdir": false,
            "luzindir": "de 2 a 6 horas",
            "url": "https://verdecora.es/10904-large_default/dieffembachia-camilla-maceta-3-litros.jpg",
            "enlace": "https://verdecora.es/buscar?controller=search&orderby=position&orderway=desc&search_query=Dieffembachia&submit_search="
        }
    ]
}