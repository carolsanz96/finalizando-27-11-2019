/**
 * Clase 'ResultadoFiltros' que guardará los datos del Json
 */

class ResultadoFiltrosHoras {
/**
     * Constructor de clases de la clase ResultadoFiltrosHoras
     * @param {any} resultadoHoras Resultado del filtro 'Horas' a guardar
     * */
    constructor(resultadoHoras) {
        this.resultadoHoras = resultadoHoras;
    }
}