var florOb;
var arrDatosFlor = [];
var cuidadosOb;
var arrDatosCuidados = [];
var arrDatosHoras = [];
var plantasInterior;
var arrPlantasInt = [];
var PlantaOb;
var resultados = {
    flor: 'selectAll',
    cuidados: 'selectAll',
    horas: 'selectAll'
};
var estado = 'flor';

var btn_1 = document.getElementById('siguiente');
var btn_2 = document.getElementById('siguiente2');
var btn_3 = document.getElementById('siguiente3');
var btn_4 = document.getElementById('siguiente4');

$(document).ready(function () {
    //ejecutarLlamadaAjax();
    guardarInformacion(plantas);
});
function ejecutarLlamadaAjax() {
    var peticion = new XMLHttpRequest();
    peticion.onreadystatechange = function () {
        if (peticion.readyState == 4 && peticion.status == 200) {
            plantasInterior = JSON.parse(plantas);
            guardarInformacion(plantasInterior);
            //crearTabla(arrPlantasInt);
            //console.log(plantasInterior);
        } else {
            //alert("La base de datos no está disponible en estos momentos");
        }
    }
    peticion.overrideMimeType("text/plain");
    peticion.open("GET", "https://raw.githubusercontent.com/carolsanz96/plantasInterior.json/master/PlantasInterior.json");
    peticion.send(null);
}
function saveInfo(event, tipo) {

    var boton = document.getElementById("siguiente");

    if (event.value) {
        resultados[tipo] = event.value;
        estado = tipo;
        boton.disabled = false;
    }
}

function next() {
    var elementos = Array.from(document.getElementsByClassName('classToFilter'));
    elementos.forEach(element => {
        element.classList.add('none');
    });
    if (estado === 'flor') {
        var eleme = document.getElementById('div_cuidados');
        eleme.classList.remove('none');
        var elemeLabel = document.getElementById('general-label');
        elemeLabel.innerHTML = 'Cuidados';
        var boton = document.getElementById("siguiente");
        boton.disabled = true;
    } else if (estado === 'cuidados') {
        var eleme = document.getElementById('div_horas');
        eleme.classList.remove('none');
        var elemeLabel = document.getElementById('general-label');
        elemeLabel.innerHTML = 'Horas';
        var boton = document.getElementById("siguiente");
        boton.disabled = true;
    } else if (estado === 'horas') {
        crearInfo();
        funcionFiterAll();
    }
}

function crearInfo() {
    var filterInfo = document.getElementById('filtros-finales');
    var vals = Object.values(resultados);
    var keys = Object.keys(resultados);
    vals.forEach((element, i) => {
        var div = document.createElement('div');
        var p = document.createElement('p');
        p.innerHTML = keys[i] + ': ' + element;
        div.appendChild(p);
        filterInfo.appendChild(div);
    });
}

function crearFlor() {
    document.getElementById("labelCuidados").style.display = "inline";
    document.getElementById('siguiente').style.display = 'none';
    document.getElementById('siguiente2').style.display = 'inline';

    var resultadoFlor = "ninguno";

    var florSi = document.getElementsByName("flor");
    // Recorremos todos los valores del radio button para encontrar el
    // seleccionado
    for (var i = 0; i < florSi.length; i++) {
        if (florSi[i].checked)
            resultadoFlor = florSi[i].value;
    }

    document.getElementById("resultado").innerHTML = " \
            Flor: "+ resultadoFlor;
    console.log(resultadoFlor);
    florOb = new ResultadoFiltrosFlor(resultadoFlor);
    //lo añade al constructor mediante un 'push'
    arrDatosFlor.push(florOb);
    console.log(florOb);
    borrarTablaFlores();
    document.getElementById("labelAlto").style.display = "inline";
    document.getElementById("Alto").style.display = "inline";
    document.getElementById("labelNormal").style.display = "inline";
    document.getElementById("Normal").style.display = "inline";
    document.getElementById("labelBajo").style.display = "inline";
    document.getElementById("Bajo").style.display = "inline";

}

function borrarTablaFlores() {
    // borra la tabla

    const tableToDelete = document.getElementById('table_flores');
    if (tableToDelete) {
        tableToDelete.parentElement.removeChild(tableToDelete);
    }
    //crearTablaFiltros(arrDatosFlor);
}

function radioCuidados() {


    var cuidadoAlto = document.getElementById("Alto");
    var cuidadoNormal = document.getElementById("Normal");
    var cuidadoBajo = document.getElementById("Bajo");
    var boton = document.getElementById("siguiente2");
    //boton.disabled == true;
    if (cuidadoAlto.checked == true || cuidadoNormal.checked == true || cuidadoBajo.checked == true) {
        boton.disabled = false;
    } else if (cuidadoAlto.checked == false && cuidadoBajo.checked == false && cuidadoNormal.checked == false) {
        boton.disabled = true;
    }
}

function crearCuidados() {
    document.getElementById("labelHoras").style.display = "inline";
    document.getElementById('siguiente2').style.display = 'none';
    document.getElementById('siguiente4').style.display = 'inline';

    var resultadoCuidados = "ninguno";
    var cuidadosSi = document.getElementsByName("cuidados");
    for (var i = 0; i < cuidadosSi.length; i++) {
        if (cuidadosSi[i].checked)
            resultadoCuidados = cuidadosSi[i].value;
    }

    document.getElementById("resultado2").innerHTML = " \
            Cuidados: "+ resultadoCuidados;
    console.log(resultadoCuidados);
    cuidadosOb = new ResultadoFiltrosCuidados(resultadoCuidados);
    //lo añade al constructor mediante un 'push'
    arrDatosCuidados.push(cuidadosOb);
    console.log(arrDatosCuidados);
    borrarTablaCuidados();
    document.getElementById("label2a6").style.display = "inline";
    document.getElementById("de2a6").style.display = "inline";
    document.getElementById("labelmas6").style.display = "inline";
    document.getElementById("masde6").style.display = "inline";
    document.getElementById("labelmenos2").style.display = "inline";
    document.getElementById("menosde2").style.display = "inline";
    //crearTablaFiltrosCuidados(arrDatosCuidados);
}

function borrarTablaCuidados() {
    // borra la tabla

    const tableToDelete = document.getElementById('table_cuidados');
    if (tableToDelete) {
        tableToDelete.parentElement.removeChild(tableToDelete);
    }
    //crearTablaFiltros(arrDatosFlor);
}

function radioHoras(event) {


    var horas2a6 = document.getElementById("de2a6");
    var horasmas6 = document.getElementById("masde6");
    var horasmenos6 = document.getElementById("menosde2");
    var boton = document.getElementById("siguiente4");
    //boton.disabled == true;
    if (horas2a6.checked == true || horasmas6.checked == true || horasmenos6.checked == true) {
        boton.disabled = false;
    } else if (horas2a6.checked == false && horasmas6.checked == false && horasmenos6.checked == false) {
        boton.disabled = true;
    }
}
function crearHoras() {
    document.getElementById('siguiente2').style.display = 'none';
    document.getElementById('siguiente4').style.display = 'inline';

    var resultadoHoras = "ninguno";
    var horasSi = document.getElementsByName("horas");
    for (var i = 0; i < horasSi.length; i++) {
        if (horasSi[i].checked)
            resultadoHoras = horasSi[i].value;
    }

    document.getElementById("resultado3").innerHTML = " \
            Horas: "+ resultadoHoras;
    console.log(resultadoHoras);
    cuidadosOb = new ResultadoFiltrosHoras(resultadoHoras);
    //lo añade al constructor mediante un 'push'
    arrDatosHoras.push(cuidadosOb);
    console.log(arrDatosHoras);
    //crearTablaFiltrosHoras(arrDatosHoras);
    funcionFiterAll();
}

function borrarTablaHoras() {
    // borra la tabla

    const tableToDelete = document.getElementById('table_horas');
    if (tableToDelete) {
        tableToDelete.parentElement.removeChild(tableToDelete);
    }

    //crearTablaFiltros(arrDatosFlor);

}
/**
 * Función que guarda la información del Json en un Array de clases Series
 * @param {JSON} plantasInterior 
 */

function guardarInformacion(plantasInterior) {
    var plantaJson = plantasInterior.plantasInterior;

    for (i = 0; i < plantaJson.length; i++) {
        var nombre = plantaJson[i].nombre;
        var codin = plantaJson[i].codin;
        var precio = plantaJson[i].precio;
        var oferta = plantaJson[i].oferta;
        var arrUbicaciones = new Array();
        for (j = 0; j < plantaJson[i].ubicacion.length; j++) {
            var ubicacion = plantaJson[i].ubicacion[j].lugar;
            arrUbicaciones.push(ubicacion);
        }
        //Comprobante de que coge el array de la ubicacion de las plantas
        //console.log(plantaJson[i].ubicacion);
        var flor = plantaJson[i].flor;
        var cuidados = plantaJson[i].cuidados;
        var luzdir = plantaJson[i].luzdir;
        var luzindir = plantaJson[i].luzindir;
        var url = plantaJson[i].url;
        var enlace = plantaJson[i].enlace;
        PlantaOb = new PlantaInterior(nombre, codin, precio, oferta, arrUbicaciones, flor, cuidados, luzdir, luzindir, url, enlace);

        //lo añade al constructor mediante un 'push'
        arrPlantasInt.push(PlantaOb);

    }
}
/**
 * Funcion que crea la Tabla de HTML en la que se le pasa un array de clases Serie
 * @param {Array} arrPlantasInt  Array de clases Plantas
 */
//Esta funcion recoge las plantas obtenidas en 'guardarInformacion' y crea una tabla con los datos que deseemos que muestre
function crearTabla(arrPlantasInt) {
    //Este 'divMostrar' Sirve para meterlo todo dentro de un div independiente de la tabla ya creada con el formulario
    var divMostrar = document.getElementById("mostrar");
    divMostrar.innerHTML = "";
    var table = document.createElement("table");
    table.id = "tabla_flores";
    table.setAttribute("border", "1");
    var trCabecera = document.createElement("tr");
    var tdC1 = document.createElement("td");
    var tdC2 = document.createElement("td");
    var tdC3 = document.createElement("td");
    var tdC4 = document.createElement("td");
    var tdC5 = document.createElement("td");
    var tdC6 = document.createElement("td");
    var tdC7 = document.createElement("td");
    var tdC8 = document.createElement("td");
    var tdC9 = document.createElement("td");
    var tdC10 = document.createElement("td");


    var tnC1 = document.createTextNode("Nombre");
    var tnC2 = document.createTextNode("Codin");
    var tnC3 = document.createTextNode("Precio");
    var tnC4 = document.createTextNode("Oferta");
    var tnC5 = document.createTextNode("Ubicación");

    var tnC6 = document.createTextNode("Flor");
    var tnC7 = document.createTextNode("Cuidados");
    var tnC8 = document.createTextNode("Luz Directa");
    var tnC9 = document.createTextNode("Luz Indirecta");
    var tnC10 = document.createTextNode("Url");




    tdC1.appendChild(tnC1);
    tdC2.appendChild(tnC2);
    tdC3.appendChild(tnC3);
    tdC4.appendChild(tnC4);
    tdC5.appendChild(tnC5);
    tdC6.appendChild(tnC6);
    tdC7.appendChild(tnC7);
    tdC8.appendChild(tnC8);
    tdC9.appendChild(tnC9);
    tdC10.appendChild(tnC10);


    trCabecera.appendChild(tdC1);
    trCabecera.appendChild(tdC2);
    trCabecera.appendChild(tdC3);
    trCabecera.appendChild(tdC4);
    trCabecera.appendChild(tdC5);
    trCabecera.appendChild(tdC6);
    trCabecera.appendChild(tdC7);
    trCabecera.appendChild(tdC8);
    trCabecera.appendChild(tdC9);
    trCabecera.appendChild(tdC10);


    table.appendChild(trCabecera);

    if (arrPlantasInt.length != 0) {
        for (let i = 0; i < arrPlantasInt.length; i++) {


            console.log(arrPlantasInt[i].nombre);
            console.log(arrPlantasInt[i].codin);
            console.log(arrPlantasInt[i].precio);
            console.log(arrPlantasInt[i].oferta);
            console.log(arrPlantasInt[i].ubicacion);
            console.log(arrPlantasInt[i].flor);
            console.log(arrPlantasInt[i].cuidados);
            console.log(arrPlantasInt[i].luzdir);
            console.log(arrPlantasInt[i].luzindir);
            console.log(arrPlantasInt[i].url);
            console.log(arrPlantasInt[i].enlace);

            var tr = document.createElement("tr");
            var td1 = document.createElement("td");
            var td2 = document.createElement("td");
            var td3 = document.createElement("td");
            var td4 = document.createElement("td");
            var td5 = document.createElement("td");
            var td6 = document.createElement("td");
            var td7 = document.createElement("td");
            var td8 = document.createElement("td");
            var td9 = document.createElement("td");
            var td10 = document.createElement("td");
            td10.classList.add('container-img');

            var tn1 = document.createTextNode(arrPlantasInt[i].nombre);
            var tn2 = document.createTextNode(arrPlantasInt[i].codin);
            var tn3 = document.createTextNode(arrPlantasInt[i].precio);
            var tn4 = document.createTextNode(arrPlantasInt[i].oferta);
            for (let j = 0; j < arrPlantasInt[i].ubicacion.length; j++) {

                console.log(arrPlantasInt[i].ubicacion[j]);
                var tn5 = document.createTextNode(arrPlantasInt[i].ubicacion);
            }
            var tn6 = document.createTextNode(arrPlantasInt[i].flor);
            var tn7 = document.createTextNode(arrPlantasInt[i].cuidados);
            var tn8 = document.createTextNode(arrPlantasInt[i].luzdir);
            var tn9 = document.createTextNode(arrPlantasInt[i].luzindir);

            //Se crea una variable img para pasarle la url
            var img = document.createElement("img");
            //le pones attribute src y le pasas la url
            img.setAttribute("src", arrPlantasInt[i].url);
            var container = document.createElement('div');
            container.classList.add('nameContainer');
            var enlace = document.createElement('a');
            enlace.text = arrPlantasInt[i].nombre;
            enlace.href = arrPlantasInt[i].enlace;
            container.appendChild(enlace);

            td1.appendChild(tn1);
            td2.appendChild(tn2);
            td3.appendChild(tn3);
            td4.appendChild(tn4);
            td5.appendChild(tn5);
            td6.appendChild(tn6);
            td7.appendChild(tn7);
            td8.appendChild(tn8);
            td9.appendChild(tn9);
            //lo añades
            td10.appendChild(img);
            td10.appendChild(container);


            tr.appendChild(td1);
            tr.appendChild(td2);
            tr.appendChild(td3);
            tr.appendChild(td4);
            tr.appendChild(td5);
            tr.appendChild(td6);
            tr.appendChild(td7);
            tr.appendChild(td8);
            tr.appendChild(td9);
            tr.appendChild(td10);

            table.appendChild(tr);
            console.log(arrPlantasInt[i].nombre);
            console.log(arrPlantasInt[i].ubicacion);
            console.log(arrPlantasInt[i].flor);
            console.log(arrPlantasInt[i].enlace);

        }
        document.body.appendChild(table);
    }
    console.log("que contiene array de plantas int");
    console.log(document.getElementById('mostrar').innerText);


}
$(".tablaMostrar").hide();
function desaparecerTabla() {
    let text = "";
    if ($("#buttonBuscar").text() === "Buscar") {
        $(".tablaMostrar").show();
        text = "Hide form";
    } else {
        $(".tablaMostrar").hide();
        text = "Buscar";
    }
    $(("#buttonBuscar").html(text));
}
// borra la tabla

function borrarTabla() {
    const tableToDelete = document.getElementById('tabla_flores');
    if (tableToDelete) {
        tableToDelete.parentElement.removeChild(tableToDelete);
    }
}


function filtrarV2(value, nameFilter, arrayAux) {

    return arrayAux.filter(element => {
        if (value === 'No lo se') {
            return true;
        }
        if (Array.isArray(element[nameFilter])) {
            return element[nameFilter].includes(value);
        } else if (typeof element[nameFilter] === 'string') {
            return element[nameFilter] === value;
        } else if (element[nameFilter] === true || element[nameFilter] === false) {
            if (element[nameFilter]) {
                return 'Si' === value;
            } else {
                return 'No' === value;
            }
        }
    });

}
function funcionFiterAll() {
    borrarTabla();

    var arrayAux = arrPlantasInt.filter(eleme => {
        if (eleme.cuidados === resultados.cuidados || resultados.cuidados === 'selectAll') {
            if (eleme.luzindir === resultados.horas || resultados.horas === 'selectAll') {
                if (eleme.flor && (resultados.flor === 'Si' || resultados.flor === 'selectAll')) {
                    return eleme;
                }
                if (!eleme.flor && (resultados.flor === 'No' || resultados.flor === 'selectAll')) {
                    return eleme;
                }
            }
        }
    });
    crearTabla(arrayAux);
}

