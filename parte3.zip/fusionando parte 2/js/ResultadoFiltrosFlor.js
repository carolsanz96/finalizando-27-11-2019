/**
 * Clase 'ResultadoFiltros' que guardará los datos del Json
 */

class ResultadoFiltrosFlor {
/**
     * Constructor de clases de la clase ResultadoFiltros
     * @param {any} resultadoFlor Resultado del filtro 'Flor' a guardar
     * */
    constructor(resultadoFlor) {
        this.resultadoFlor = resultadoFlor;
    }
}